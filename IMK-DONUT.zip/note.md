navbar{
  navbar-dark
  garis pink dihilangkan
}

logo{
  logo diubah
}

home{
  background pink => background="image" + bg-overlay
}